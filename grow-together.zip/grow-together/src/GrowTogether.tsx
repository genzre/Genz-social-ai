import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';

export default function GrowTogether() {
  const [growthLevel, setGrowthLevel] = useState(1);

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gradient-to-br from-pink-200 via-purple-300 to-indigo-400">
      <motion.div
        className="text-center"
        initial={{ scale: 0.9 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold text-white mb-4">
          Grow Together
        </h1>
        <p className="text-white text-lg max-w-md mb-8">
          Every tap strengthens your bond. Every beat is mutual growth. One heart. One path.
        </p>
      </motion.div>

      <motion.button
        onClick={() => setGrowthLevel((prev) => prev + 1)}
        whileTap={{ scale: 0.9 }}
        className="focus:outline-none"
      >
        <motion.div
          animate={{ scale: 1 + growthLevel * 0.1 }}
          transition={{ type: "spring", stiffness: 200, damping: 10 }}
        >
          <Heart size={48} className="text-white" fill="currentColor" />
        </motion.div>
      </motion.button>

      <p className="mt-6 text-white">
        Growth Level: <span className="font-semibold">{growthLevel}</span>
      </p>
    </div>
  );
}
