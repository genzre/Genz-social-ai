import GrowTogether from './GrowTogether';

function App() {
  return <GrowTogether />;
}

export default App;
