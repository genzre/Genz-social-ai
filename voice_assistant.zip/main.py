import speech_recognition as sr
import pyttsx3
import datetime
import wikipedia
import openai
import webbrowser
import os

# Initialize
recognizer = sr.Recognizer()
engine = pyttsx3.init()

# Set your OpenAI key
openai.api_key = "YOUR_API_KEY"

def speak(text):
    engine.say(text)
    engine.runAndWait()

def listen():
    with sr.Microphone() as source:
        print("Listening...")
        audio = recognizer.listen(source)
    try:
        query = recognizer.recognize_google(audio)
        print("You said:", query)
        return query.lower()
    except sr.UnknownValueError:
        speak("Sorry, I didn't understand that.")
        return ""
    except Exception as e:
        speak("Something went wrong.")
        return ""

def get_gpt_response(prompt):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo", messages=[{"role": "user", "content": prompt}]
    )
    return response['choices'][0]['message']['content']

def main():
    speak("Hello! I'm your assistant.")
    while True:
        query = listen()
        
        if "exit" in query or "quit" in query:
            speak("Goodbye!")
            break
        elif "your name" in query:
            speak("I'm your personal assistant.")
        elif "time" in query:
            current_time = datetime.datetime.now().strftime("%H:%M")
            speak(f"It's {current_time}")
        elif "date" in query:
            today = datetime.date.today().strftime("%B %d, %Y")
            speak(f"Today is {today}")
        elif "wikipedia" in query:
            topic = query.replace("wikipedia", "").strip()
            result = wikipedia.summary(topic, sentences=2)
            speak(result)
        elif "open" in query:
            if "google" in query:
                webbrowser.open("https://www.google.com")
                speak("Opening Google")
            elif "youtube" in query:
                webbrowser.open("https://www.youtube.com")
                speak("Opening YouTube")
        elif query:
            response = get_gpt_response(query)
            speak(response)
        else:
            speak("Please say that again.")

if __name__ == "__main__":
    main()